<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$busca = isset($_GET['busca']) ? $_GET['busca'] : '';

if ($busca != '') {
    $sql = "SELECT * FROM clientes WHERE nome LIKE '%$busca%' OR cpf LIKE '%$busca%'";
} else {
    $sql = "SELECT * FROM clientes";
}

$resultado = $conn->query($sql);
?>

<h2>Listagem de Clientes</h2>
<a href="../index.php">Voltar ao Menu</a> | 
<a href="inserir.php">Cadastrar Novo Cliente</a>
<br><br>

<form method="get" action="">
    <input type="text" name="busca" placeholder="Buscar por nome ou CPF" value="<?php echo $busca; ?>">
    <button type="submit">Buscar</button>
    <a href="listar.php">Limpar</a>
</form>

<br>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>CPF</th>
        <th>Telefone</th>
        <th>Email</th>
        <th>Ações</th>
    </tr>
    <?php while ($linha = $resultado->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $linha['id']; ?></td>
        <td><?php echo $linha['nome']; ?></td>
        <td><?php echo $linha['cpf']; ?></td>
        <td><?php echo $linha['telefone']; ?></td>
        <td><?php echo $linha['email']; ?></td>
        <td>
            <a href="atualizar.php?id=<?php echo $linha['id']; ?>">Editar</a> |
            <a href="apagar.php?id=<?php echo $linha['id']; ?>" onclick="return confirm('Deseja realmente excluir?')">Excluir</a>
        </td>
    </tr>
    <?php } ?>
</table>