<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

if (isset($_POST['nome'])) {
    $nome     = $_POST['nome'];
    $cpf      = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $email    = $_POST['email'];
    $endereco = $_POST['endereco'];

    $sql = "INSERT INTO clientes (nome, cpf, telefone, email, endereco) 
            VALUES ('$nome', '$cpf', '$telefone', '$email', '$endereco')";
    
    if ($conn->query($sql)) {
        header("Location: listar.php");
    }
}
?>

<h2>Cadastrar Cliente</h2>
<form method="post" action="">
    Nome: <input type="text" name="nome" required><br><br>
    CPF: <input type="text" name="cpf" required><br><br>
    Telefone: <input type="text" name="telefone"><br><br>
    Email: <input type="email" name="email"><br><br>
    Endereço: <input type="text" name="endereco"><br><br>
    <button type="submit">Salvar</button>
    <a href="listar.php">Cancelar</a>
</form>