<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$id = $_GET['id'];
$cliente = $conn->query("SELECT * FROM clientes WHERE id = $id")->fetch_assoc();

if (isset($_POST['nome'])) {
    $nome     = $_POST['nome'];
    $cpf      = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $email    = $_POST['email'];
    $endereco = $_POST['endereco'];

    $sql = "UPDATE clientes SET nome='$nome', cpf='$cpf', telefone='$telefone', email='$email', endereco='$endereco' WHERE id=$id";
    if ($conn->query($sql)) {
        header("Location: listar.php");
    }
}
?>

<h2>Atualizar Cliente</h2>
<form method="post" action="">
    Nome: <input type="text" name="nome" value="<?php echo $cliente['nome']; ?>" required><br><br>
    CPF: <input type="text" name="cpf" value="<?php echo $cliente['cpf']; ?>" required><br><br>
    Telefone: <input type="text" name="telefone" value="<?php echo $cliente['telefone']; ?>"><br><br>
    Email: <input type="email" name="email" value="<?php echo $cliente['email']; ?>"><br><br>
    Endereço: <input type="text" name="endereco" value="<?php echo $cliente['endereco']; ?>"><br><br>
    <button type="submit">Atualizar</button>
    <a href="listar.php">Cancelar</a>
</form>