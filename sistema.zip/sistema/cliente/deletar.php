<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$id = $_GET['id'];
$conn->query("DELETE FROM clientes WHERE id = $id");
header("Location: listar.php");
?>