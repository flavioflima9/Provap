<?php
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

include "conexao.php";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel - Locadora</title>
    <style>
        /* Estilos Gerais */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Fonte padrão e limpa */
        }

        body {
            background-color: #f4f6f9;
            color: #333333;
        }

        /* Barra de Topo */
        .topo-painel {
            background-color: #ffffff;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #e0e0e0;
        }

        .topo-painel h1 {
            font-size: 1.3rem;
            color: #222222;
        }

        .topo-painel h1 span {
            color: #0066cc; /* Destaca o nome do usuário em azul */
        }

        /* Link de Sair (Logout) */
        .btn-sair {
            color: #cc0000;
            text-decoration: none;
            font-weight: bold;
            padding: 8px 15px;
            border: 1px solid #cc0000;
            border-radius: 4px;
            transition: all 0.2s;
        }

        .btn-sair:hover {
            background-color: #cc0000;
            color: #ffffff;
        }

        /* Conteúdo Principal */
        .conteudo {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .conteudo h2 {
            margin-bottom: 25px;
            color: #555555;
            font-size: 1.2rem;
        }

        /* Menu de Navegação em Blocos */
        .menu-navegacao {
            display: flex;
            flex-wrap: wrap; /* Permite que os blocos quebrem de linha em telas menores */
            gap: 20px;
        }

        /* Estilo dos Botões de Gerenciamento */
        .btn-menu {
            flex: 1;
            min-width: 250px; /* Garante um tamanho bom para leitura */
            background-color: #ffffff;
            color: #333333;
            text-decoration: none;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid #dddddd;
            text-align: center;
            font-size: 1.1rem;
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            transition: transform 0.2s, border-color 0.2s, color 0.2s;
        }

        /* Efeito de passar o mouse nos botões */
        .btn-menu:hover {
            transform: translateY(-3px);
            border-color: #0066cc;
            color: #0066cc;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

    <!-- Barra superior com saudação e opção de sair -->
    <div class="topo-painel">
        <h1>Bem-vindo, <span><?php echo htmlspecialchars($_SESSION['nome']); ?></span>!</h1>
        <a href="logout.php" class="btn-sair">Sair do Sistema</a>
    </div>

    <!-- Corpo da página -->
    <div class="conteudo">
        <h2>Selecione uma opção de gerenciamento:</h2>

        <nav class="menu-navegacao">
            <a href="cliente/listar.php" class="btn-menu">Gerenciar Clientes</a>
            <a href="veiculo/listar.php" class="btn-menu">Gerenciar Veículos</a>
            <a href="locacao/listar.php" class="btn-menu">Gerenciar Locações</a>
        </nav>
    </div>

</body>
</html>
