<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$clientes = $conn->query("SELECT * FROM clientes");
$veiculos = $conn->query("SELECT * FROM veiculos");

if (isset($_POST['cliente_id'])) {
    $cliente_id     = $_POST['cliente_id'];
    $veiculo_id     = $_POST['veiculo_id'];
    $data_retirada  = $_POST['data_retirada'];
    $data_devolucao = $_POST['data_devolucao'];
    $valor_total    = $_POST['valor_total'];

    $sql = "INSERT INTO locacoes (cliente_id, veiculo_id, data_retirada, data_devolucao, valor_total, status) 
            VALUES ('$cliente_id', '$veiculo_id', '$data_retirada', '$data_devolucao', '$valor_total', 'ativa')";
    
    if ($conn->query($sql)) {
        header("Location: listar.php");
    }
}
?>

<h2>Nova Locação</h2>
<form method="post" action="">
    Cliente:
    <select name="cliente_id" required>
        <option value="">Selecione o Cliente</option>
        <?php while($c = $clientes->fetch_assoc()) { ?>
            <option value="<?php echo $c['id']; ?>"><?php echo $c['nome']; ?></option>
        <?php } ?>
    </select><br><br>

    Veículo:
    <select name="veiculo_id" required>
        <option value="">Selecione o Veículo</option>
        <?php while($v = $veiculos->fetch_assoc()) { ?>
            <option value="<?php echo $v['id']; ?>"><?php echo $v['modelo'] . " - " . $v['placa']; ?></option>
        <?php } ?>
    </select><br><br>

    Data Retirada: <input type="date" name="data_retirada" required><br><br>
    Data Devolução: <input type="date" name="data_devolucao" required><br><br>
    Valor Total (R$): <input type="text" name="valor_total" required><br><br>

    <button type="submit">Cadastrar Locação</button>
    <a href="listar.php">Cancelar</a>
</form>