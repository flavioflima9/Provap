<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$sql = "SELECT l.*, c.nome AS cliente_nome, v.modelo AS veiculo_modelo, v.placa AS veiculo_placa
        FROM locacoes l
        JOIN clientes c ON l.cliente_id = c.id
        JOIN veiculos v ON l.veiculo_id = v.id
        ORDER BY l.data_retirada DESC";

$resultado = $conn->query($sql);
?>

<h2>Listagem de Locações</h2>
<a href="../index.php">Voltar ao Menu</a> | <a href="inserir.php">Nova Locação</a>
<br><br>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Cliente</th>
        <th>Veículo</th>
        <th>Retirada</th>
        <th>Devolução</th>
        <th>Valor Total</th>
        <th>Status</th>
        <th>Ações</th>
    </tr>
    <?php while ($linha = $resultado->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $linha['id']; ?></td>
        <td><?php echo $linha['cliente_nome']; ?></td>
        <td><?php echo $linha['veiculo_modelo'] . " (" . $linha['veiculo_placa'] . ")"; ?></td>
        <td><?php echo $linha['data_retirada']; ?></td>
        <td><?php echo $linha['data_devolucao']; ?></td>
        <td>R$ <?php echo $linha['valor_total']; ?></td>
        <td><?php echo $linha['status']; ?></td>
        <td>
            <a href="apagar.php?id=<?php echo $linha['id']; ?>" onclick="return confirm('Deseja cancelar/excluir?')">Excluir</a>
        </td>
    </tr>
    <?php } ?>
</table>