<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$id = $_GET['id'];
$veiculo = $conn->query("SELECT * FROM veiculos WHERE id = $id")->fetch_assoc();

if (isset($_POST['placa'])) {
    $placa        = $_POST['placa'];
    $marca        = $_POST['marca'];
    $modelo       = $_POST['modelo'];
    $ano          = $_POST['ano'];
    $valor_diaria = $_POST['valor_diaria'];
    $status       = $_POST['status'];

    $sql = "UPDATE veiculos SET placa='$placa', marca='$marca', modelo='$modelo', ano='$ano', valor_diaria='$valor_diaria', status='$status' WHERE id=$id";
    if ($conn->query($sql)) {
        header("Location: listar.php");
    }
}
?>

<h2>Atualizar Veículo</h2>
<form method="post" action="">
    Placa: <input type="text" name="placa" value="<?php echo $veiculo['placa']; ?>"><br><br>
    Marca: <input type="text" name="marca" value="<?php echo $veiculo['marca']; ?>"><br><br>
    Modelo: <input type="text" name="modelo" value="<?php echo $veiculo['modelo']; ?>"><br><br>
    Ano: <input type="number" name="ano" value="<?php echo $veiculo['ano']; ?>"><br><br>
    Valor Diária: <input type="text" name="valor_diaria" value="<?php echo $veiculo['valor_diaria']; ?>"><br><br>
    Status: 
    <select name="status">
        <option value="disponivel" <?php if($veiculo['status']=='disponivel') echo 'selected'; ?>>Disponível</option>
        <option value="alugado" <?php if($veiculo['status']=='alugado') echo 'selected'; ?>>Alugado</option>
    </select><br><br>
    <button type="submit">Atualizar</button>
    <a href="listar.php">Cancelar</a>
</form>