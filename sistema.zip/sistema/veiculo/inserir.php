<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

if (isset($_POST['placa'])) {
    $placa        = $_POST['placa'];
    $marca        = $_POST['marca'];
    $modelo       = $_POST['modelo'];
    $ano          = $_POST['ano'];
    $valor_diaria = $_POST['valor_diaria'];

    $sql = "INSERT INTO veiculos (placa, marca, modelo, ano, valor_diaria) 
            VALUES ('$placa', '$marca', '$modelo', '$ano', '$valor_diaria')";
    if ($conn->query($sql)) {
        header("Location: listar.php");
    }
}
?>

<h2>Cadastrar Veículo</h2>
<form method="post" action="">
    Placa: <input type="text" name="placa" required><br><br>
    Marca: <input type="text" name="marca" required><br><br>
    Modelo: <input type="text" name="modelo" required><br><br>
    Ano: <input type="number" name="ano"><br><br>
    Valor Diária: <input type="text" name="valor_diaria" required><br><br>
    <button type="submit">Salvar</button>
    <a href="listar.php">Cancelar</a>
</form>