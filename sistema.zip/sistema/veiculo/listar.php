<?php
session_start();
if (!isset($_SESSION['email'])) { header('Location: ../login.php'); exit(); }
include "../conexao.php";

$resultado = $conn->query("SELECT * FROM veiculos");
?>

<h2>Listagem de Veículos</h2>
<a href="../index.php">Voltar ao Menu</a> | <a href="inserir.php">Cadastrar Novo Veículo</a>
<br><br>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Placa</th>
        <th>Marca</th>
        <th>Modelo</th>
        <th>Ano</th>
        <th>Diária (R$)</th>
        <th>Status</th>
        <th>Ações</th>
    </tr>
    <?php while ($linha = $resultado->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $linha['id']; ?></td>
        <td><?php echo $linha['placa']; ?></td>
        <td><?php echo $linha['marca']; ?></td>
        <td><?php echo $linha['modelo']; ?></td>
        <td><?php echo $linha['ano']; ?></td>
        <td><?php echo $linha['valor_diaria']; ?></td>
        <td><?php echo $linha['status']; ?></td>
        <td>
            <a href="atualizar.php?id=<?php echo $linha['id']; ?>">Editar</a> |
            <a href="apagar.php?id=<?php echo $linha['id']; ?>" onclick="return confirm('Deseja excluir?')">Excluir</a>
        </td>
    </tr>
    <?php } ?>
</table>