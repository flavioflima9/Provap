<?php
$host = "localhost";
$user = "root";
$pass = "";
$porta = 3307;
$db   = "locadora";

$conn = new mysqli($host, $user, $pass, $db, $porta );

if ($conn->connect_error) {
    die("Falha " . $conn->connect_error);
}
?>