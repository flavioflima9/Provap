<?php
include "conexao.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$erro = "";

if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Back-end seguro contra SQL Injection
    $stmt = $conn->prepare("SELECT id, nome, email, senha FROM usuario WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result()->fetch_assoc();

    if ($resultado && $senha === $resultado['senha']) {
        $_SESSION['email'] = $resultado['email'];
        $_SESSION['nome']  = $resultado['nome'];
        $_SESSION['id']    = $resultado['id'];
        header('Location: index.php');
        exit();
    } else {
        $erro = "Usuário ou senha inválidos.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Locadora</title>
    <style>
        /* Reset de estilos básicos */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Centraliza o card vertical e horizontalmente na tela */
        body {
            background-color: #f3f4f6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* Estilo do Card de Login */
        .login-container {
            background-color: #ffffff;
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #1f2937;
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }

        /* Estrutura do formulário */
        .form-group {
            margin-bottom: 1.25rem;
        }

        label {
            display: block;
            margin-bottom: 0.35rem;
            color: #4b5563;
            font-size: 0.875rem;
            font-weight: 500;
        }

        /* Estilização dos campos de texto */
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.65rem 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 1rem;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        /* Efeito visual ao clicar no campo */
        input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
        }

        /* Botão de envio */
        button {
            width: 100%;
            padding: 0.75rem;
            background-color: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
            margin-top: 0.5rem;
        }

        button:hover {
            background-color: #1d4ed8;
        }

        /* Alerta de erro estruturado */
        .erro-alerta {
            background-color: #ffeeef;
            border: 1px solid #fca5a5;
            color: #b91c1c;
            padding: 0.75rem;
            border-radius: 6px;
            margin-bottom: 1.25rem;
            font-size: 0.875rem;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>Login - Locadora</h2>

        <?php if (!empty($erro)): ?>
            <div class="erro-alerta">
                <?php echo $erro; ?>
            </div>
        <?php endif; ?>

        <form action="" method="post">
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" placeholder="Informe seu email" required>
            </div>

            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" placeholder="Informe a senha" required>
            </div>

            <button type="submit">Entrar</button>
        </form>
    </div>

</body>
</html>
